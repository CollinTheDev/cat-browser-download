fx_version 'cerulean'
game 'gta5'

author 'Your Name'
description 'Script for creating a circle with interactive menu in FiveM'
version '1.0'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependency 'warmenu'

client_script '@warmenu/warmenu.lua'